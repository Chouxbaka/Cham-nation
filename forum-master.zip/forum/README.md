# Project Forum

This project was the last of our first year of study. 

The goal of this project was to create a web forum that allows : 
-   communication between users
-   associating categories to posts 
-   liking and disliking posts
-   manage filters 

# how to run the project 
This project is deployed on heroku, so you can visit our website at 
```
https://cham-nation.herokuapp.com/
```

# the team 
This project was realised by matteo DINVILLE, ismael HACQUIN, louis REYNARD, amaury LYONNET and romain SILVY-LELIGOIS

